<?php
date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Profile extends FJ_Controller {

    function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url','date'));
    }
    public function subir_foto(){
        $status="";
        $msg="";
        $user = $this->session->userdata("usuario");
        $id = $this->input->post("id");        
        $dt=getdate();
        $file_name=base64_encode("foto-$id");
        $config["file_name"]=$file_name;
        $config["upload_path"]="resources/images/user-profile";
        $config["allowed_types"]="png|jpg|jpeg";
        $config['max_size'] = 1024*8;
        $config['max_width'] = '160';
        $config['max_height']= '160';
        $config['overwrite'] = true;
        chmod($config['upload_path'], 0777);
        $this->load->library('upload');
        $this->upload->initialize($config);
            
        if(!$this->upload->do_upload("profile_picture")){
            $status="error";
            $file_info=$this->upload->data();
            $file_name.=$file_info["file_ext"];
            $msg=$this->upload->display_errors("error","");
            echo json_encode(array(
                "success"=>false,
                "msg"=>$msg,
                "foto"=>$file_name
            ));
        }else{

            $file_info=$this->upload->data();
            $file_name.=$file_info["file_ext"];
            $this->db->update('personas', array('foto' => $config["upload_path"]."/".$file_name), "id = $id");   
            echo json_encode(array(
               "success"=>true,
               "msg"=>"Imagen subida con éxito",
               "foto"=>$file_name
            ));
        }
    }

}
