<?php

date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Grupo extends FJ_Controller {

    public function index() {
    }

    function listar() {
        $start = $this->input->post('start') ? $this->input->post('start') : 0;
        $limit = $this->input->post('limit') ? $this->input->post('limit') : PHP_INT_MAX;
        $user = $this->session->userdata("usuario");            

        $filtro = $this->input->post("filtro");        

        $this->db->select("SQL_CALC_FOUND_ROWS g.*, p.identificacion, p.primer_nombre, p.segundo_nombre, p.primer_apellido,
            p.segundo_apellido",false); 
        $this->db->from("grupos g");    
        $this->db->join('personas p', 'p.id = g.lider_id');
        $this->db->where("p.estado = 1 AND g.estado = 1 AND ".($user["perfil_id"]!=1 && $user["perfil_id"]!=2 ? " lider_id=$user[id] AND ":"")." (nombre LIKE '%$filtro%' OR identificacion LIKE '%$filtro%')");        
        $this->db->limit($limit, $start);
        $query = $this->db->get();        

        $cantidad=$this->db->query("SELECT FOUND_ROWS() as cantidad;", false);
        $cantidad=$cantidad->row_array();
 
        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array(),
            'total' => $cantidad["cantidad"]
        ));
    }

    function guardar() {        
        $lider_id = $this->input->post("lider_id");
        $nombre = trim($this->input->post("nombre"));
        $descripcion = $this->input->post("descripcion");

        $msg="";
        $success=false;
       
        $this->db->where("lider_id = $lider_id AND estado = 1", NULL, FALSE);
        $rs = $this->db->get("grupos");

        if ($rs->num_rows() === 1) {
            $msg="Este Lider Ya Esta En Otro Grupo";
            $success=false;
        }else{           
            $this->db->where("nombre = '$nombre' AND estado = 1", NULL, FALSE);
            $rs = $this->db->get("grupos");
            if ($rs->num_rows() === 1) {
                $msg="Grupo Ya Registrado";
                $success=false;
            }else{
                $data = array(
                   'lider_id' => $lider_id,
                   'nombre' => $nombre,
                   'descripcion' => $descripcion
                );

                $this->db->insert('grupos', $data);
                $msg="Grupo Registrado Correctamente";
                $success=true;
            }
        }
        
        echo json_encode(array(
            'success' => $success,
            'msg' => $msg,
            'id' => $this->db->insert_id()
        ));           
    }

    function editar() {
        $id = $this->input->post("id");        
        $lider_id = $this->input->post("lider_id");
        $nombre = trim($this->input->post("nombre"));
        $descripcion = $this->input->post("descripcion");

        $msg="";
        $success=false;

        $this->db->where('id',$id);
        $rs = $this->db->get("grupos");
        $grupoDatos = $rs->row_array();
       
        $this->db->where("lider_id = $lider_id AND lider_id != $grupoDatos[lider_id] AND estado = 1", NULL, FALSE);
        $rs = $this->db->get("grupos");

        if ($rs->num_rows() === 1) {
            $msg="Este Lider Ya Esta En Otro Grupo";
            $success=false;
        }else{           
            $this->db->where("nombre = '$nombre' AND nombre != '$grupoDatos[nombre]' AND estado = 1", NULL, FALSE);
            $rs = $this->db->get("grupos");
            if ($rs->num_rows() === 1) {
                $msg="Grupo Ya Registrado";
                $success=false;
            }else{
                $data = array(
                   'lider_id' => $lider_id,
                   'nombre' => $nombre,
                   'descripcion' => $descripcion
                );

                $this->db->update('grupos', $data, "id = $id");
                $msg="Grupo Actualizado Correctamente";
                $success=true;
            }
        }
        
        echo json_encode(array(
            'success' => $success,
            'msg' => $msg
        ));           
    }

    function eliminar() {        
        $id = $this->input->post("id");        
        $this->db->update('grupos', array('estado' => -1), "id = $id");
        $this->db->update('miembros', array('estado' => -1), "grupo_id = $id");       
        echo json_encode(array(
            'success' => true,
            'msg' => "Grupo Eliminado Correctamente"
        ));           
    }   

}
