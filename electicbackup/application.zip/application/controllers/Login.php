<?php
 
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
 
class Login extends CI_Controller {
 
    function index() {
         
    }
 
    function horaSistema(){
        echo json_encode(array(
            "ano"=>date('Y'),
            "mes"=>date('m'),
            "dia"=>date('d'),
            "hora"=>date('H'),
            "minuto"=>date('i'),
            "segundo"=>date('s')
        ));
    }
     
    function logout() {
        $this->session->sess_destroy();
        echo json_encode(array(
            'success' => true
        ));
    }
 
    function cambiarContrasena() {
        $user = $this->session->userdata("usuario");

        $data = array(            
            "clave" => md5($this->input->post("clave"))
        );
        $this->db->update('personas', $data, "id = $user[id]");
        echo json_encode(array(
            'success' => true,
            'msg' => 'Contrase&ntilde;a cambiada correctamente'
        ));          
    }
    function validarUsuario() {
        $data = array(
            "usuario" => $this->input->post("usuario"),
            "clave" => md5($this->input->post("clave")),
            "estado" => 1
        );
               
        $this->db->where($data);
        $rs = $this->db->get("personas");
        
        if ($rs->num_rows() === 1) {

            $this->db->where($data);
            $rs = $this->db->get("personas");
            $usuario = $rs->row_array();
            unset($usuario["clave"]);
 
            $this->session->set_userdata(array(
                "usuario" => $usuario
            ));
            echo json_encode(array(
                'success' => true
            ));
        } else {
            unset($data["clave"]);
            $this->db->where($data);
            $rs = $this->db->get("personas");

            if($rs->num_rows() === 1){
                echo json_encode(array(
                    'success' => false,
                    'msg' => 'Usuario y/o contrase&ntilde;a invalido.'
                ));                
            }else{
                echo json_encode(array(
                    'success' => false,
                    'msg' => 'Usuario No Existe.'                    
                ));
            }            
        }
    }
 
    function estaConectado() {
        $user = $this->session->userdata("usuario"); //["user_data"];
        echo json_encode(array(
            'success' => is_array($user),
            'usuario' => $user
        ));
    } 
}
 
?>