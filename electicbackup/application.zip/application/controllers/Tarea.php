<?php

date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Tarea extends FJ_Controller {

    public function index() {
    } 

    public function listarTareasFases(){
        $start = $this->input->post('start') ? $this->input->post('start') : 0;
        $limit = $this->input->post('limit') ? $this->input->post('limit') : PHP_INT_MAX;

        $user = $this->session->userdata("usuario");

        $query=$this->db->query("
            SELECT SQL_CALC_FOUND_ROWS t.*, v.`nombre` fase FROM elt_tareas t
            INNER JOIN elt_valorparametro v
            ON v.`id` = t.`situacion_id`
            WHERE t.`estado` = 1
            AND v.`estado` = 1
            AND t.tipo_EAP = 'tarea'
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND t.creador_id = $user[id]")."
            ORDER BY v.`id` ASC
            LIMIT $start,$limit
        ");
        $tareas = $query->result_array();

        $cantidad=$this->db->query("SELECT FOUND_ROWS() as cantidad;", false);
        $cantidad=$cantidad->row_array();

        echo json_encode(array(
            'success' => true,
            'data' => $tareas,
            'total' => $cantidad["cantidad"],
        ));
    }

    public function listarOrganigrama(){
        $query=$this->db->query("
            SELECT p.id Id, '-1' ParentId, 
            CONCAT(IFNULL(p.`primer_nombre`,''),' ',IFNULL(p.`segundo_nombre`,''),' ',IFNULL(p.`primer_apellido`,''),' ',IFNULL(p.`segundo_apellido`,'')) Name,
            CONCAT('Líder de ',g.`nombre`) Title, IF(p.`foto` IS NULL,'../resources/images/user-profile/icon-user-default.png', CONCAT('../',p.foto,'?nocache=',FLOOR(RAND()*10000000))) Image FROM
            elt_personas p
            INNER JOIN elt_grupos g
            ON p.`id` = g.`lider_id`
            WHERE p.`estado` = 1 AND g.`estado` = 1             
            UNION
            SELECT p.id Id, l.id ParentId, 
            CONCAT(IFNULL(p.`primer_nombre`,''),' ',IFNULL(p.`segundo_nombre`,''),' ',IFNULL(p.`primer_apellido`,''),' ',IFNULL(p.`segundo_apellido`,'')) Name,
            g.`nombre` Title, IF(p.`foto` IS NULL,'../resources/images/user-profile/icon-user-default.png', CONCAT('../',p.foto,'?nocache=',FLOOR(RAND()*10000000))) Image FROM
            elt_personas p
            INNER JOIN elt_miembros m
            ON m.`persona_id` = p.`id`
            INNER JOIN elt_grupos g
            ON g.`id` = m.`grupo_id`
            INNER JOIN elt_personas l
            ON l.`id` = g.`lider_id`
            WHERE p.`estado` = 1 AND g.`estado` = 1 AND l.`estado` = 1
        ",false);
        
        echo json_encode($query->result_array());
    }

    public function listarFinanzas(){   
        $start = $this->input->post('start') ? $this->input->post('start') : 0;
        $limit = $this->input->post('limit') ? $this->input->post('limit') : PHP_INT_MAX;     

        $user = $this->session->userdata("usuario");

        $fecha_inicial = $this->input->post("fecha_inicial");
        $fecha_final = $this->input->post("fecha_final");
        $fase_id = $this->input->post("fase_id");
        $nombreTarea = $this->input->post("nombreTarea");

        $query=$this->db->query("
            SELECT SQL_CALC_FOUND_ROWS
            i.`id`, i.`nombre`, i.`valor_estimado`, i.`valor_real`, t.id idTarea, t.`nombre` nombreTarea,
            t.`fecha_hora_inicio`, t.`fecha_hora_final`, t.`situacion_id`, vp.`nombre` nombreFase
            FROM elt_tareas t
            INNER JOIN elt_insumos i
            ON i.`tarea_id` = t.id
            LEFT JOIN elt_valorparametro vp
            ON vp.`id` = t.`situacion_id`
            AND vp.`estado` = 1
            WHERE t.`estado` = 1
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND t.creador_id = $user[id]")." 
            AND i.`estado` = 1  
            ".(!empty($fecha_inicial) ? "AND (DATE(t.`fecha_hora_inicio`) >= '$fecha_inicial' AND DATE(t.`fecha_hora_final`) <= '$fecha_final')":"")."
            ".(!empty($fase_id) ? "AND vp.`id` = $fase_id":"")." AND t.`nombre` LIKE '%$nombreTarea%'
            LIMIT $start,$limit
        ",false);        

        $cantidad=$this->db->query("SELECT FOUND_ROWS() as cantidad;", false);
        $cantidad=$cantidad->row_array();

        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array(),
            'total' => $cantidad["cantidad"]
        ));
    }    

    public function editarInsumo(){        
        $valor_estimado = $this->input->post("valor_estimado");        
        $valor_real = $this->input->post("valor_real");                
        $id = $this->input->post("id");

        $data = array(                      
           'valor_estimado' => $valor_estimado,
           'valor_real' => $valor_real           
        );
        $this->db->update('insumos', $data, "id = $id");                    

        echo json_encode(array(
            'success' => true,
            'msg' => "Insumo Actualizado Correctamente"
        ));
    } 

    public function eliminarInsumo() {        
        $id = $this->input->post("id");        
        $this->db->update('insumos', array('estado' => -1), "id = $id");        
        echo json_encode(array(
            'success' => true,
            'msg' => "Insumo Eliminado Correctamente"
        ));           
    }  

    public function listarInsumos(){
        $tarea_id = $this->input->post("tarea_id");
        $filtro = $this->input->post("filtro");
        $this->db->where("estado = 1 AND tarea_id = $tarea_id AND nombre LIKE '%$filtro%'");        
        $query = $this->db->get("insumos");

        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array()
        ));
    }

    public function guardarInsumo(){
        $nombre = trim($this->input->post("nombre"));                
        $valor_estimado = $this->input->post("valor_estimado");        
        $valor_real = $this->input->post("valor_real");        
        $tarea_id = $this->input->post("tarea_id");

        $data = array(
           'tarea_id' => $tarea_id,
           'nombre' => $nombre,           
           'valor_estimado' => $valor_estimado,
           'valor_real' => $valor_real           
        );
        $this->db->insert('insumos', $data);                    

        echo json_encode(array(
            'success' => true,
            'msg' => "Insumo Registrado Correctamente",
            'id' => $this->db->insert_id()
        ));
    }

    public function editar(){
        $nombre = trim($this->input->post("nombre"));
        $descripcion = trim($this->input->post("descripcion"));
        $prioridad_EAP = $this->input->post("prioridad_EAP");
        $situacion_id = $this->input->post("situacion_id");
        $valor_estimado = $this->input->post("valor_estimado");        
        $valor_real = $this->input->post("valor_real");
        $fecha_hora_inicio = $this->input->post("fecha_hora_inicio");
        $fecha_hora_final = $this->input->post("fecha_hora_final");
        $color = $this->input->post("color");
        $tipo_EAP = $this->input->post("tipo_EAP");
        $ubicacion = $this->input->post("ubicacion");
        $id = $this->input->post("id");

        $user = $this->session->userdata("usuario");

        $data = array(
           'creador_id' => $user["id"],
           'nombre' => $nombre,
           'descripcion' => $descripcion,
           'prioridad_EAP' => $prioridad_EAP,           
           'situacion_id' => $situacion_id,           
           'valor_estimado' => $valor_estimado,
           'valor_real' => $valor_real,
           'fecha_hora_inicio' => $fecha_hora_inicio,
           'fecha_hora_final' => $fecha_hora_final,
           'fecha_hora_creacion' => date("Y-m-d_H-i-s"),
           'color' => $color,       
           'ubicacion' => $ubicacion,    
           'tipo_EAP' => $tipo_EAP
        );
        $this->db->update('tareas', $data, "id = $id");        
                
        echo json_encode(array(
            'success' => true,
            'msg' => "Tarea Actualizada Correctamente"
        ));
    }

    public function eliminarTareaSubTarea() {        
        $id = $this->input->post("id");        
        $this->db->update('tareas_sub_tareas', array('estado' => -1), "id = $id");        
        echo json_encode(array(
            'success' => true,
            'msg' => "Tarea - Sub Tarea Eliminada Correctamente"
        ));           
    }

    public function eliminar() {        
        $id = $this->input->post("id");        
        $this->db->update('tareas', array('estado' => -1), "id = $id");
        $this->db->update('tareas_sub_tareas', array('estado' => -1), "sub_tarea_id = $id OR tarea_id = $id");        
        echo json_encode(array(
            'success' => true,
            'msg' => "Tarea Eliminada Correctamente"
        ));           
    }

    public function listarTareasHijas(){
        $tarea_id = $this->input->post("tarea_id");
        $filtro = $this->input->post("filtro");        

        $this->db->select("t.*, st.tarea_id tarea_padre",false); 
        $this->db->from("elt_tareas t");    
        $this->db->join('elt_tareas_sub_tareas st', 'st.sub_tarea_id = t.id');
        $this->db->where("t.estado = 1 AND st.estado = 1 AND st.tarea_id = $tarea_id AND t.nombre LIKE '%$filtro%'");        
        $this->db->group_by("t.id");
        $query = $this->db->get();         

        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array()
        ));
    }

    public function listarFases(){
        $this->db->where("estado = 1 AND parametro_id = 1");        
        $query = $this->db->get("elt_valorparametro");

        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array()
        ));
    }

    public function guardar(){
        $nombre = trim($this->input->post("nombre"));
        $descripcion = trim($this->input->post("descripcion"));
        $prioridad_EAP = $this->input->post("prioridad_EAP");
        $situacion_id = $this->input->post("situacion_id");
        $valor_estimado = $this->input->post("valor_estimado");        
        $valor_real = $this->input->post("valor_real");
        $fecha_hora_inicio = $this->input->post("fecha_hora_inicio");
        $fecha_hora_final = $this->input->post("fecha_hora_final");
        $color = $this->input->post("color");
        $tipo_EAP = $this->input->post("tipo_EAP");
        $padre_id = $this->input->post("padre_id");
        $ubicacion = $this->input->post("ubicacion");

        $user = $this->session->userdata("usuario");

        $data = array(
           'creador_id' => $user["id"],
           'nombre' => $nombre,
           'descripcion' => $descripcion,
           'prioridad_EAP' => $prioridad_EAP,           
           'situacion_id' => $situacion_id,           
           'valor_estimado' => $valor_estimado,
           'valor_real' => $valor_real,
           'fecha_hora_inicio' => $fecha_hora_inicio,
           'fecha_hora_final' => $fecha_hora_final,
           'fecha_hora_creacion' => date("Y-m-d_H-i-s"),
           'color' => $color,
           'ubicacion' => $ubicacion,
           'tipo_EAP' => $tipo_EAP
        );
        $this->db->insert('tareas', $data);
        $idTarea = $this->db->insert_id();    
        
        if(!empty($padre_id)){
            $data = array(
               'tarea_id' => $padre_id,
               'sub_tarea_id' => $idTarea
            );
            $this->db->insert('elt_tareas_sub_tareas', $data);    
        }

        echo json_encode(array(
            'success' => true,
            'msg' => "Tarea Registrada Correctamente",
            'id' => $idTarea
        ));
    }

    function eliminarResponsable() {        
        $id = $this->input->post("id");        
        $this->db->update('compromisos', array('estado' => -1), "id = $id");        
        echo json_encode(array(
            'success' => true,
            'msg' => "Responsable Eliminado Correctamente"
        ));           
    }

    public function guardarResponsable(){
        $id = $this->input->post("id");        
        $tipo = $this->input->post("tipo");
        $tarea_id = $this->input->post("tarea_id");        
        $campo = "";

        $data = array(
           'tarea_id' => $tarea_id
        );

        $persona["email"] = "";
        if($tipo=="persona"){
            $campo = "delegado_id";
            
            $this->db->where(array("estado"=>1, "id" =>$id));
            $query = $this->db->get("personas");                                           
            $persona = $query->row_array();

        }else{
            $campo = "grupos_id";            
        }

        $data[$campo] = $id;            
        $this->db->insert('compromisos', $data);                

        $this->db->where(array("estado"=>1, "id" =>$tarea_id));
        $query = $this->db->get("tareas");                

        $this->correos->enviarCorreo($persona["email"],"Notificación",$this->load->view('correos',$query->row_array(),true));

        echo json_encode(array(
            'success' => true,
            'msg' => "Responsable Registrado Correctamente"
        )); 
    }

    public function listarResponsables(){
        $query = $this->input->post("query");
        $tarea_id = $this->input->post("tarea_id");

        $user = $this->session->userdata("usuario");

        if(empty($tarea_id)){
            $query2=$this->db->query("
                SELECT tabla.*
                    FROM(SELECT p.`id`, CONCAT(IFNULL(p.`primer_nombre`,''), ' ', IFNULL(p.`primer_apellido`,''), ' ', IFNULL(p.`segundo_apellido`,'')) nombre,
                    'persona' tipo
                    FROM elt_personas p                 
                    WHERE p.`estado` = 1 AND p.`tipo_EAP` = 'miembro'
                    AND p.perfil_id != 1
                    UNION
                    SELECT g.id, g.nombre, 'grupo' tipo FROM elt_grupos g                   
                    WHERE g.`estado` = 1) tabla
                HAVING tabla.nombre LIKE '%$query%'
            ",false);
        }else{
            $query2=$this->db->query("
                SELECT tabla.*
                    FROM(SELECT p.`id`, CONCAT(IFNULL(p.`primer_nombre`,''), ' ', IFNULL(p.`primer_apellido`,''), ' ', IFNULL(p.`segundo_apellido`,'')) nombre,
                    'persona' tipo
                    FROM elt_personas p 
                    LEFT JOIN elt_compromisos c
                    ON c.`delegado_id` = p.`id`
                    AND c.`estado` = 1
                    AND c.`tarea_id` = $tarea_id                                
                    WHERE c.`id` IS NULL AND p.`estado` = 1 AND p.`tipo_EAP` = 'miembro'
                    AND p.perfil_id != 1
                    UNION
                    SELECT g.id, g.nombre, 'grupo' tipo FROM elt_grupos g   
                    LEFT JOIN elt_compromisos c
                    ON c.`grupos_id` = g.id
                    AND c.`estado` = 1
                    AND c.`tarea_id` = $tarea_id
                    WHERE c.id IS NULL AND g.`estado` = 1) tabla
                HAVING tabla.nombre LIKE '%$query%'
            ",false);
        }                
        
        echo json_encode(array(
            'success' => true,
            'data' => $query2->result_array()
        ));
    }

    public function listarResponsablesTarea(){
        $filtro = $this->input->post("filtro");
        $tarea_id= $this->input->post("tarea_id");
        $query=$this->db->query("
            SELECT tabla.*
            FROM(SELECT c.`id`, CONCAT(IFNULL(p.`primer_nombre`,''), ' ', IFNULL(p.`primer_apellido`,''), ' ', IFNULL(p.`segundo_apellido`,'')) nombre FROM elt_compromisos c
                INNER JOIN elt_personas p
                ON p.`id` = c.`delegado_id`
                WHERE p.`estado` = 1 AND c.`estado` = 1
                AND c.`tarea_id` = $tarea_id            
                UNION
                SELECT c.id, g.nombre FROM elt_compromisos c
                INNER JOIN elt_grupos g
                ON g.`id` = c.`grupos_id`
                WHERE g.`estado` = 1 AND c.`estado` = 1
                AND c.`tarea_id` = $tarea_id) tabla
            HAVING tabla.nombre LIKE '%$filtro%'
        ",false);

        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array()
        )); 
    }

    public function obtenerCalendario() {

        $mes= $this->input->post("mes");
        $ano= $this->input->post("ano");
        $tipo_EAP= $this->input->post("tipo_EAP");

        $user = $this->session->userdata("usuario");

        $dias = array("domingo","lunes","martes","miercoles","jueves","viernes","sabado");
        $dias_mes = cal_days_in_month(CAL_GREGORIAN, $mes, $ano);       

        $calendario = array();
        $semana = array();
        $semanas = array();
        $fechas = array();

        for ($i = 1; $i <= $dias_mes; $i++) { 

            $fecha = new DateTime($i.'-'.$mes.'-'.$ano);

            array_push($fechas, $fecha);

            if(!in_array($fecha->format('W'), $semanas)) {
                array_push($semanas, $fecha->format('W'));
            }           
        }  

        $this->festivos->festivos($ano);         

        for ($i = 1; $i <= $dias_mes; $i++) {           

            $numero_dia = $fechas[$i - 1]->format('w');
            $dia_semana = $dias[$numero_dia];

            $fechaAMDG= $fechas[$i - 1]->format('Y-m-d');
            
            $query=$this->db->query("
                SELECT t.* FROM elt_tareas t
                LEFT JOIN
                (SELECT st.`id`, st.`sub_tarea_id` FROM elt_tareas_sub_tareas st WHERE st.`estado` = 1 GROUP BY st.`sub_tarea_id`) tabla
                ON tabla.sub_tarea_id = t.`id`
                WHERE t.`estado` = 1 
                ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND t.creador_id = $user[id]")."
                AND DATE(t.fecha_hora_inicio) = '$fechaAMDG' AND tipo_EAP = '$tipo_EAP'
                AND tabla.id IS NULL
            ");
            $arrayTareas = $query->result_array();

            foreach ($query->result_array() as $key => $value) {
                $this->db->select("t.*",false); 
                $this->db->from("elt_tareas t");    
                $this->db->join('elt_tareas_sub_tareas st', 'st.sub_tarea_id = t.id');
                $this->db->where("t.estado = 1 AND st.estado = 1 AND st.tarea_id = $value[id]");        
                $this->db->group_by("t.id");
                $query = $this->db->get(); 
                $arrayTareas[$key]["tasks"] = $query->result_array();
            }
            
            $semana[$dia_semana] = array(
                        'dia' => $i, 
                        'fecha' => $fechas[$i - 1]->format('d-m-Y'),
                        'hoy' => $fechas[$i - 1]->format('d-m-Y') == date('d-m-Y') ? true : false,
                        'festivo' => $this->festivos->esFestivo($fechas[$i - 1]->format('d'), $fechas[$i - 1]->format('m')),
                        'data' => $arrayTareas);                     
            
            if($numero_dia == 6) {
                
                array_push($calendario, $semana);
                unset($semana);             

            } else if($fechas[$i - 1]->format('W') == $semanas[count($semanas) - 1] && $i == $dias_mes){
                
                array_push($calendario, $semana);
                unset($semana);
            }            
            
        }

        echo json_encode(array(
            'success' => true,
            'data' => $calendario
        ));        
    }

    public function pruebaCorreo(){
        $this->db->where(array("estado"=>1, "id" =>14));
        $query = $this->db->get("tareas");        
        //$this->correos->enviarCorreo("javc2009@gmail.com,fvargas@ingenieria21.co","Notificación","dasd");
        $this->correos->enviarCorreo("javc2009@gmail.com,fvargas@ingenieria21.co","Notificación",$this->load->view('correos',$query->row_array(),true));
    }

    public function obtenerTotales(){
        $user = $this->session->userdata("usuario");
        $query=$this->db->query("
            SELECT COUNT(p.`id`) cant_adeptos, 
            (SELECT SUM(tabla.cantidad) cantidad FROM(SELECT COUNT(t.`id`) cantidad FROM elt_tareas t
            WHERE t.`estado` = 1
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND t.creador_id = $user[id]")."            
            AND t.tipo_EAP='tarea'
            UNION
            SELECT COUNT(DISTINCT t.`id`) cantidad FROM elt_tareas t
            INNER JOIN elt_compromisos c
            ON c.`tarea_id` = t.`id`
            WHERE t.`estado` = 1
            AND c.`estado` = 1
            AND t.`creador_id` != $user[id]
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND c.`delegado_id` = $user[id]")."            
            AND t.tipo_EAP='tarea'
            GROUP BY t.`id`)tabla) cant_tareas,
            (SELECT SUM(tabla.cantidad) cantidad FROM(SELECT COUNT(t.`id`) cantidad FROM elt_tareas t
            WHERE t.`estado` = 1
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND t.creador_id = $user[id]")."
            AND t.tipo_EAP='evento'
            UNION
            SELECT COUNT(DISTINCT t.`id`) cantidad FROM elt_tareas t
            INNER JOIN elt_compromisos c
            ON c.`tarea_id` = t.`id`
            WHERE t.`estado` = 1
            AND c.`estado` = 1
            AND t.`creador_id` != $user[id]
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND t.creador_id = $user[id]")."
            AND t.tipo_EAP='evento'
            GROUP BY t.`id`)tabla) cant_eventos,
            IFNULL((SELECT SUM(i.`valor_estimado`) FROM elt_tareas t
            INNER JOIN elt_insumos i
            ON i.`tarea_id` = t.`id`
            WHERE t.`estado` = 1
            AND i.`estado` = 1
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND t.creador_id = $user[id]")."
            GROUP BY t.`id`),0) sumEstimado,
            IFNULL((SELECT SUM(i.valor_real) FROM elt_tareas t
            INNER JOIN elt_insumos i
            ON i.`tarea_id` = t.`id`
            WHERE t.`estado` = 1
            AND i.`estado` = 1
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND t.creador_id = $user[id]")."
            GROUP BY t.`id`),0) sumReal
            FROM elt_personas p
            WHERE p.`estado` = 1 
            AND p.`tipo_EAP` ='adepto'
            ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND p.`padre_id` = $user[id]")."            
        ");
        
        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array()
        ));
    }
    
}
