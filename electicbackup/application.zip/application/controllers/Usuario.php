<?php

date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Usuario extends FJ_Controller {

    public function index() {
    }

    function listar() {
        $start = $this->input->post('start') ? $this->input->post('start') : 0;
        $limit = $this->input->post('limit') ? $this->input->post('limit') : PHP_INT_MAX;

        $filtro= $this->input->post("filtro");

        $this->db->select("SQL_CALC_FOUND_ROWS p.id, p.usuario, pf.nombre perfil, p.email",false);
        $this->db->from("personas p");
        $this->db->join("perfiles pf","pf.id = p.perfil_id");
        $this->db->where("p.estado = 1 AND pf.estado = 1 AND (p.usuario LIKE '%$filtro%' OR pf.nombre LIKE '%$filtro%')");        
        $this->db->limit($limit,$start);
        $query = $this->db->get();

        $cantidad=$this->db->query("SELECT FOUND_ROWS() as cantidad;", false);
        $cantidad=$cantidad->row_array();
         
        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array(),
            'total' => $cantidad["cantidad"],
        ));
    }

    function listarMiembros() {        
        $query= $this->input->post("query");
        $user = $this->session->userdata("usuario");

        $this->db->where("estado = 1 AND p.perfil_id != 1");   
        $this->db->where("(p.primer_nombre LIKE '%$query%' OR p.primer_apellido LIKE '%$query%')", NULL, FALSE);     
        $query2 = $this->db->get("personas p");

        echo json_encode(array(
            'success' => true,
            'data' => $query2->result_array()
        ));
    }

    function guardar() {        
        $perfil_id = $this->input->post("perfil_id");
        $usuario = $this->input->post("usuario");
        $clave = $this->input->post("clave");
        $email = $this->input->post("email");

        $msg="";
        $success=false;
       
        $this->db->where('usuario',$usuario);
        $rs = $this->db->get("personas");

        if ($rs->num_rows() === 1) {
            $msg="Usuario Ya Registrado";
            $success=false;
        }else{           
            $this->db->where('email',$email);
            $rs = $this->db->get("personas");
            if ($rs->num_rows() === 1) {
                $msg="Email Ya Registrado";
                $success=false;
            }else{
                $data = array(
                   'perfil_id' => $perfil_id,
                   'usuario' => trim($usuario),
                   'clave' => md5($clave),
                   'email' => trim($email)
                );

                $this->db->insert('personas', $data);
                $msg="Usuario Registrado Correctamente";
                $success=true;
            }
        }
        
        echo json_encode(array(
            'success' => $success,
            'msg' => $msg
        ));           
    }

    function editar() {
        $id = $this->input->post("id");        
        $perfil_id = $this->input->post("perfil_id");
        $usuario = $this->input->post("usuario");
        $clave = $this->input->post("clave");
        $email = $this->input->post("email");

        $msg="";
        $success=false;       

        $this->db->where('id',$id);
        $rs = $this->db->get("personas");
        $usuarioDatos = $rs->row_array();

        $this->db->where("usuario = '$usuario' AND usuario != '$usuarioDatos[usuario]'", NULL, FALSE);
        $rs = $this->db->get("personas");

        if ($rs->num_rows() === 1) {
            $msg="Usuario Ya Registrado";
            $success=false;
        }else{           
            $this->db->where("email = '$email' AND email != '$usuarioDatos[email]'", NULL, FALSE);
            $rs = $this->db->get("personas");
            if ($rs->num_rows() === 1) {
                $msg="Email Ya Registrado";
                $success=false;
            }else{
                $data = array(
                   'perfil_id' => $perfil_id,
                   'usuario' => trim($usuario),
                   'clave' => md5($clave),
                   'email' => trim($email)
                );
                
                $this->db->update('personas', $data, "id = $id");
                $msg="Usuario Actualizado Correctamente";
                $success=true;
            }
        }

        echo json_encode(array(
            'success' => $success,
            'msg' => $msg
        ));           
    }

    function eliminar() {        
        $id = $this->input->post("id");        
        $this->db->update('personas', array('estado' => -1), "id = $id");       
        echo json_encode(array(
            'success' => true,
            'msg' => "Usuario Eliminado Correctamente"
        ));           
    }   

}
