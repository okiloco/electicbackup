<?php

date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Perfil extends FJ_Controller {

    public function index() {
    }

    function listar() {
        $start = $this->input->post('start') ? $this->input->post('start') : 0;
        $limit = $this->input->post('limit') ? $this->input->post('limit') : PHP_INT_MAX;

        $filtro= $this->input->post("filtro"); 

        $queryAdmin = "id != 1 AND id != 2";
        $user = $this->session->userdata("usuario");    
           
        $this->db->select("SQL_CALC_FOUND_ROWS *",false);
        $this->db->where("estado",1);
        if(!($user["perfil_id"]==1 || $user["perfil_id"]==2)){
            $this->db->where($queryAdmin, NULL, FALSE);     
        }
        $this->db->like("nombre",$filtro);
        $this->db->limit($limit, $start);
        $query = $this->db->get("perfiles");

        $cantidad=$this->db->query("SELECT FOUND_ROWS() as cantidad;", false);
        $cantidad=$cantidad->row_array();

        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array(),
            'total' => $cantidad["cantidad"]
        ));
    }
}
