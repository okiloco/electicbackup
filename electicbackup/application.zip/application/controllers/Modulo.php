<?php

date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Modulo extends FJ_Controller {

    public function index() {
    }

    public function cargarMenu($node = 0) {
        $user = $this->session->userdata("usuario");            
        $result = $this->db->query("
                SELECT 
                  id,
                  nombre text,
                  URI view,
                  iconCls,
                  replace(nombre,' ','') routeId,
                  IF(expanded=1,'true','false') expanded,                  
                  IF(selectable=1,'true','false') selectable,
                  IF((SELECT 
                    COUNT(*) 
                  FROM
                    elt_modulos 
                  WHERE padre_id = m.id 
                    AND id IN (
                        SELECT modulo_id FROM elt_acciones
                        WHERE id IN (
                            SELECT accion_id FROM elt_permisos
                            WHERE perfil_id IN (
                                SELECT perfil_id FROM elt_personas
                                WHERE id=$user[id]
                            )
                        )                        
                        AND nombre='ver'
                   ))>0,'false','true') leaf,
                  (SELECT 
                    COUNT(*) 
                  FROM
                    elt_modulos 
                  WHERE padre_id = m.id 
                    AND id IN (
                        SELECT modulo_id FROM elt_acciones
                        WHERE id IN (
                            SELECT accion_id FROM elt_permisos
                            WHERE perfil_id IN (
                                SELECT perfil_id FROM elt_personas
                                WHERE id=$user[id]
                            )
                        )                        
                        AND nombre='ver'
                   )) AS cantidadHijo 
                FROM
                  elt_modulos AS m 
                WHERE  
                  id IN (
                    SELECT modulo_id FROM elt_acciones
                        WHERE id IN (
                            SELECT accion_id FROM elt_permisos
                            WHERE perfil_id IN (
                                SELECT perfil_id FROM elt_personas
                                WHERE id=$user[id]
                            )
                        )                        
                        AND nombre='ver'
                  )            
                  AND padre_id = $node
                  AND estado = 1 
                  ORDER BY orden ASC
            ", false);
        $resultado = $result->result_array();
        foreach ($resultado as $k => $v) {
            if ($v['cantidadHijo'] > 0) {
                $resultado[$k]['children'] = $this->cargarMenu($v['id']);
            }
        }            
        if ($node == 0) {
            echo json_encode(array(                
                'data' => $resultado
            ));                
        } else {
            return $resultado;
        }        
    }
}
