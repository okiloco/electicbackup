<?php

date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Persona extends FJ_Controller {

    public function index() {
    }

    function listarAdeptos() {
        $start = $this->input->post('start') ? $this->input->post('start') : 0;
        $limit = $this->input->post('limit') ? $this->input->post('limit') : PHP_INT_MAX;

        $filtro= $this->input->post("filtro");

        $queryAdmin = "AND p.perfil_id != 1 AND p.perfil_id != 2";
        $user = $this->session->userdata("usuario");

        $esAdmin = false;
        if($user["perfil_id"]==1){
            $esAdmin = true;
        }
        
        $this->db->select("SQL_CALC_FOUND_ROWS p.*, pf.nombre perfil, p.padre_id, IFNULL(padre.identificacion,'') ident_padre, padre.primer_nombre pdnombre1,
            padre.segundo_nombre pdnombre2, padre.primer_apellido pdapellido1, padre.segundo_apellido pdapellido2",false);
        $this->db->from("personas p");
        $this->db->join("personas padre","padre.id = p.padre_id AND padre.estado = 1",($esAdmin?"left":"inner"));
        $this->db->join("perfiles pf","pf.id = p.perfil_id AND pf.estado = 1","left");        
        $this->db->where("p.estado = 1 ".($esAdmin?"":"AND p.padre_id=$user[id]")." AND p.tipo_EAP = 'adepto'"."
            AND (p.primer_nombre LIKE '%$filtro%' OR p.primer_apellido LIKE '%$filtro%' OR p.identificacion LIKE '%$filtro%')", NULL, FALSE);
        $this->db->limit($limit,$start);
        $query = $this->db->get();
        $personas = $query->result_array();
        
        foreach ($personas as $index => $data) {            
            unset($personas[$index]["clave"]);            
        }

        $cantidad=$this->db->query("SELECT FOUND_ROWS() as cantidad;", false);
        $cantidad=$cantidad->row_array();

        echo json_encode(array(
            'success' => true,
            'data' => $personas,
            'total' => $cantidad["cantidad"],
        ));
    }

    function listar() {
        $start = $this->input->post('start') ? $this->input->post('start') : 0;
        $limit = $this->input->post('limit') ? $this->input->post('limit') : PHP_INT_MAX;
        
        $filtro= $this->input->post("filtro");
        $query= $this->input->post("query");

        $queryAdmin = "AND p.perfil_id != 1 AND p.perfil_id != 2";
        $user = $this->session->userdata("usuario");
        
        $this->db->select("SQL_CALC_FOUND_ROWS p.*, pf.nombre perfil, p.padre_id, IFNULL(padre.identificacion,'') ident_padre, padre.primer_nombre pdnombre1,
            padre.segundo_nombre pdnombre2, padre.primer_apellido pdapellido1, padre.segundo_apellido pdapellido2",false);
        $this->db->from("personas p");
        $this->db->join("perfiles pf","pf.id = p.perfil_id AND pf.estado = 1","left");
        $this->db->join("personas padre","padre.id = p.padre_id AND padre.estado = 1","left");
        $this->db->where(($user["perfil_id"]==1? "" : "p.perfil_id != 1 AND")." p.estado = 1 AND p.tipo_EAP = 'miembro'", NULL, FALSE);

        if(!empty($filtro)){
            $this->db->where("(p.primer_nombre LIKE '%$filtro%' OR p.primer_apellido LIKE '%$filtro%' OR p.identificacion LIKE '%$filtro%')", NULL, FALSE);
        }elseif(!empty($query)){
            $this->db->where("(p.primer_nombre LIKE '%$query%' OR p.primer_apellido LIKE '%$query%' OR p.identificacion LIKE '%$query%')", NULL, FALSE);
        }

        $this->db->limit($limit,$start);
        $query2 = $this->db->get();
        $personas = $query2->result_array();
        
        foreach ($personas as $index => $data) {            
            unset($personas[$index]["clave"]);            
            $personas[$index]["foto"] = ($personas[$index]["foto"]==null?null:$personas[$index]["foto"].'?nocache='.rand(0,10000000));
        }

        $cantidad=$this->db->query("SELECT FOUND_ROWS() as cantidad;", false);
        $cantidad=$cantidad->row_array();

        echo json_encode(array(
            'success' => true,
            'data' => $personas,
            'total' => $cantidad["cantidad"],
        ));
    }

    function guardar() {       
        $tipo_EAP = $this->input->post("tipo_EAP");
        $clave = $this->input->post("clave");
        $usuario = trim($this->input->post("usuario"));
        $email = trim($this->input->post("email"));
        $primer_nombre = $this->input->post("primer_nombre");
        $segundo_nombre = $this->input->post("segundo_nombre");
        $primer_apellido = $this->input->post("primer_apellido");
        $segundo_apellido = $this->input->post("segundo_apellido");
        $identificacion = trim($this->input->post("identificacion"));
        $telefono = $this->input->post("telefono");      
        $celular = $this->input->post("celular");
        $direccion = $this->input->post("direccion");
        $barrio = $this->input->post("barrio");
        $padre_id = $this->input->post("padre_id");
        $perfil_id = $this->input->post("perfil_id");

        $msg="";
        $success=false;
       
        $this->db->where("identificacion = '$identificacion' AND estado = 1", NULL, FALSE);
        $rs = $this->db->get("personas");

        if ($rs->num_rows() === 1) {
            $msg="Persona Ya Registrada";
            $success=false;
        }else{

            $this->db->where('usuario',$usuario);
            $this->db->where('estado',1);
            $rs = $this->db->get("personas");
            if ($rs->num_rows() === 1 && !empty($usuario)) {
                $msg="Usuario Ya Registrado";
                $success=false;
            }else{

                $this->db->where("email = '$email' AND estado = 1 AND tipo_EAP != 'adepto'", NULL, FALSE);
                $rs = $this->db->get("personas");
                if ($rs->num_rows() === 1) {
                    $msg="Email Ya Registrado";
                    $success=false;
                }else{        
                    $data = array(               
                       'clave' => md5($clave),
                       'tipo_EAP' => $tipo_EAP,
                       'usuario' => $usuario,
                       'email' => trim($email),
                       'primer_nombre' => $primer_nombre,
                       'segundo_nombre' => $segundo_nombre,
                       'primer_apellido' => $primer_apellido,
                       'segundo_apellido' => $segundo_apellido,
                       'identificacion' => $identificacion,
                       'telefono' => $telefono,
                       'celular' => $celular,               
                       'direccion' => $direccion,
                       'barrio' => $barrio,
                       'padre_id' => empty($padre_id)?null:$padre_id,
                       'perfil_id' => $perfil_id
                    );

                    $this->db->insert('personas', $data);
                    $msg="Persona Registrada Correctamente";
                    $success=true;
                }
            }            
        }
        
        echo json_encode(array(
            'success' => $success,
            'msg' => $msg,
            'id' => $this->db->insert_id()
        ));           
    }

    function editar() {
        $tipo_EAP = $this->input->post("tipo_EAP");        
        $usuario = trim($this->input->post("usuario"));  
        $id = $this->input->post("id");     
        $email = trim($this->input->post("email"));
        $primer_nombre = $this->input->post("primer_nombre");
        $segundo_nombre = $this->input->post("segundo_nombre");
        $primer_apellido = $this->input->post("primer_apellido");
        $segundo_apellido = $this->input->post("segundo_apellido");
        $identificacion = trim($this->input->post("identificacion"));
        $telefono = $this->input->post("telefono");      
        $celular = $this->input->post("celular");
        $direccion = $this->input->post("direccion");
        $barrio = $this->input->post("barrio");
        $padre_id = $this->input->post("padre_id");
        $perfil_id = $this->input->post("perfil_id");

        $msg="";
        $success=false;

        $this->db->where('id',$id);
        $rs = $this->db->get("personas");
        $personaDatos = $rs->row_array();
       
        $this->db->where("identificacion = '$identificacion' AND identificacion != '$personaDatos[identificacion]' AND estado = 1", NULL, FALSE);
        $rs = $this->db->get("personas");

        if ($rs->num_rows() === 1) {
            $msg="Persona Ya Registrada";
            $success=false;
        }else{ 
            $this->db->where("usuario = '$usuario' AND usuario != '$personaDatos[usuario]' AND estado = 1", NULL, FALSE);
            $rs = $this->db->get("personas");

            if ($rs->num_rows() === 1) {
                $msg="Usuario Ya Registrado";
                $success=false;
            }else{
                $this->db->where("email = '$email' AND email != '$personaDatos[email]' AND estado = 1 AND tipo_EAP != 'adepto'", NULL, FALSE);
                $rs = $this->db->get("personas");
                if ($rs->num_rows() === 1) {
                    $msg="Email Ya Registrado";
                    $success=false;
                }else{        
                    $data = array(                                      
                       'tipo_EAP' => $tipo_EAP,
                       'usuario' => $usuario,
                       'email' => trim($email),
                       'primer_nombre' => $primer_nombre,
                       'segundo_nombre' => $segundo_nombre,
                       'primer_apellido' => $primer_apellido,
                       'segundo_apellido' => $segundo_apellido,
                       'identificacion' => trim($identificacion),
                       'telefono' => $telefono,
                       'celular' => $celular,               
                       'direccion' => $direccion,
                       'barrio' => $barrio,
                       'padre_id' => empty($padre_id)?null:$padre_id,
                       'perfil_id' => $perfil_id
                    );

                    $this->db->update('personas', $data, "id = $id");
                    $msg="Persona Actualizada Correctamente";
                    $success=true;
                }
            }            
        }
        
        echo json_encode(array(
            'success' => $success,
            'msg' => $msg
        ));           
    }

    function eliminar() {        
        $id = $this->input->post("id");        
        $this->db->update('personas', array('estado' => -1), "id = $id");       
        echo json_encode(array(
            'success' => true,
            'msg' => "Persona Eliminada Correctamente"
        ));           
    }   

}
