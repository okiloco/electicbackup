<?php

date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Permiso extends FJ_Controller {

    public function index() {
    }

    function cargarPermisos() {
        $user = $this->session->userdata("usuario");
        $id = $this->input->post("id");        
        $query = $this->db->query("
            SELECT a.*
            FROM elt_modulos AS m, 
            elt_acciones AS a, 
            elt_permisos AS p
            WHERE m.id = " . $id . "
            AND m.id = a.modulo_id 
            AND a.id = p.accion_id
            AND p.perfil_id = " . $user["perfil_id"] . "
            AND m.estado = 1
            AND a.estado = 1
        ");

        echo json_encode(array(
            'success' => true,
            'permisos' => $query->result_array()
        ));
    }
}
