<?php

date_default_timezone_set('America/Bogota');
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Miembro extends FJ_Controller {

    public function index() {
    }

    function listarPersonasSinGrupos() {        
        $query= $this->input->post("query");
        $user = $this->session->userdata("usuario");

        $this->db->select("p.*");
        $this->db->from("personas p");
        $this->db->join("miembros m","m.persona_id = p.id AND m.estado = 1","left");
        $this->db->where("m.persona_id IS NULL AND p.estado = 1 AND p.perfil_id != 1");                
        $this->db->where("(p.primer_nombre LIKE '%$query%' OR p.primer_apellido LIKE '%$query%')", NULL, FALSE);     
        $query2 = $this->db->get();    

        echo json_encode(array(
            'success' => true,
            'data' => $query2->result_array()
        ));
    }

    function listar() {
        $start = $this->input->post('start') ? $this->input->post('start') : 0;
        $limit = $this->input->post('limit') ? $this->input->post('limit') : PHP_INT_MAX;

        $filtro= $this->input->post("filtro");
        $grupo_id= $this->input->post("grupo_id");

        $user = $this->session->userdata("usuario");

        $this->db->select("SQL_CALC_FOUND_ROWS m.*, p.identificacion, p.primer_nombre, p.segundo_nombre, p.primer_apellido,
            p.segundo_apellido, g.nombre grupo",false); 
        $this->db->from("miembros m");    
        $this->db->join('personas p', 'p.id = m.persona_id');
        $this->db->join('grupos g', 'g.id = m.grupo_id');        
        $this->db->where("g.id = '$grupo_id' ".($user["perfil_id"]==1 || $user["perfil_id"]==2?"":"AND g.lider_id=$user[id]")." AND p.estado = 1 AND g.estado = 1 AND m.`estado` = 1 AND (nombre LIKE '%$filtro%' OR identificacion LIKE '%$filtro%')");        
        $this->db->limit($limit, $start);
        $query = $this->db->get();

        $cantidad=$this->db->query("SELECT FOUND_ROWS() as cantidad;", false);
        $cantidad=$cantidad->row_array();

        echo json_encode(array(
            'success' => true,
            'data' => $query->result_array(),
            'total' => $cantidad["cantidad"]
        ));
    }

    function guardar() {        
        $grupo_id = $this->input->post("grupo_id");
        $persona_id = trim($this->input->post("persona_id"));

        $msg="";
        $success=false;
       
        $this->db->where("grupo_id = $grupo_id AND persona_id = $persona_id AND estado = 1", NULL, FALSE);
        $rs = $this->db->get("miembros");

        if ($rs->num_rows() === 1) {
            $msg="Grupo - Miembro Ya Esta Registrado";
            $success=false;
        }else{                                   
            $data = array(
               'grupo_id' => $grupo_id,
               'persona_id' => $persona_id
            );

            $this->db->insert('miembros', $data);
            $msg="Grupo - Miembro Registrado Correctamente";
            $success=true;
        }
        
        echo json_encode(array(
            'success' => $success,
            'msg' => $msg
        ));           
    }

    function editar() {
        $id = $this->input->post("id");        
        $grupo_id = $this->input->post("grupo_id");
        $persona_id = trim($this->input->post("persona_id"));

        $msg="";
        $success=false;      
       
        $this->db->where("grupo_id = $grupo_id AND persona_id = $persona_id AND estado = 1 AND id != $id", NULL, FALSE);
        $rs = $this->db->get("miembros");

        if ($rs->num_rows() === 1) {
            $msg="Grupo - Miembro Ya Esta Registrado";
            $success=false;
        }else{                       
            $data = array(
               'grupo_id' => $grupo_id,
               'persona_id' => $persona_id
            );
            
            $this->db->update('miembros', $data, "id = $id");
            $msg="Grupo - Miembro Actualizado Correctamente";
            $success=true;            
        }
        
        echo json_encode(array(
            'success' => $success,
            'msg' => $msg
        ));           
    }

    function eliminar() {        
        $id = $this->input->post("id");        
        $this->db->update('miembros', array('estado' => -1), "id = $id");       
        echo json_encode(array(
            'success' => true,
            'msg' => "Grupo - Miembro Eliminado Correctamente"
        ));           
    }   

}
