<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">	

</head>
<body>

		<div style="background:#f9f9f9;padding:40px 0;margin:10px 0;border-bottom:1px solid #efefef">
            <table style="border-spacing:0;border-collapse:collapse;width:100%;vertical-align:top;max-width:580px;margin:0 auto;padding:0;font-size:15px">
              <tbody><tr>
                <td>
                  
            <h1><span style="display:inline-block;width:10px;background:#0fa2e2;min-height:32px;margin-right:15px;vertical-align:top"></span>
              Electic</h1>
              
              <span>Usted ha sido <?php echo ($tipo_EAP=="tarea"?"añadido(a) a tarea $nombre":"invitado(a) a evento $nombre en el horario de $fecha_hora_inicio a $fecha_hora_final en $ubicacion. Esperamos su participación, muchas gracias."); ?>                
              </span>
              <table style="border-spacing:0;border-collapse:collapse;width:100%;vertical-align:top;text-align:center;margin:20px 0;padding:0">
                <tbody><tr>
                  <td>
                    <img alt="Responsive" src="https://ci5.googleusercontent.com/proxy/QIR-MSahu5r5vVTp_wkLwDp4c5raBQeO12FWmyev37uMxwD0dmPXYzl_O0ueciriOAZ8-hFwHgxQdNY5hHy6O6aUHrzWgvOgyAHoqpjqxH-p-2iD5twzUnsu-1FdkGcMyTMsT3-ISJ42-Ab55QXogsBePoPI_Rs=s0-d-e1-ft#https://dziaodg7d4has.cloudfront.net/assets/mails/responsive-5997612a2b2cafdf2ccb02e28b9d4c10.png" class="CToWUd"><br>
                    
            <a style="color:#fff;text-decoration:none;display:inline-block;color:#fff;border-radius:2px;border-bottom-width:2px;border-bottom-color:#00a462;border-bottom-style:solid;background:#00cb6f;padding:15px 40px;margin:10px auto;font-size:18px" 
href=<?php echo ($tipo_EAP!="tarea"?"yesidjassirvergara.com/#CalendariodeEventos":"http://yesidjassirvergara.com/#AgendadeTareas"); ?> target="_blank">
              <?php echo ($tipo_EAP!="tarea"?"Asistir":"Ver Detalle"); ?>
            </a>
                    <div align="center" style="color:#aaa;font-size:14px">
                      Click en el enlace para ingresar a <?php echo ($tipo_EAP!="tarea"?"evento":"tarea"); ?>
                    </div>
                  </td>
                </tr>
              </tbody></table>



                            </td>
                          </tr>
                        </tbody></table>
                      </div>

</body>
</html>