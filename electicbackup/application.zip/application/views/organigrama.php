<html> 
<head> 
    <title>.:: Organigrama</title>	
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>	
	  	
	<script src="../getorgchart/getorgchart.js"></script>
	<link href="../getorgchart/getorgchart.css" rel="stylesheet" />
	 
    <style type="text/css">
        html, body {margin: 0px; padding: 0px;width: 100%;height: 100%;overflow: hidden; }
        #people {width: 100%;height: 100%; }   
    </style>
</head>
<body>    
    <div id="people"></div>
    <script type="text/ecmascript">
	 
		var readUrl = "Tarea/listarOrganigrama";
	 
		$.getJSON(readUrl, function(people) {		
			$('#people').getOrgChart({
				clickEvent:function(){
					return false;
				},
				primaryColumns: ["Name", "Title"],
				imageColumn: "Image",
				linkType: "M",
				editable: false,
				dataSource: people,
				color: "lightblue",
				orientation: getOrgChart.RO_TOP, 
			});
		});

    </script>	
</body>
</html>
