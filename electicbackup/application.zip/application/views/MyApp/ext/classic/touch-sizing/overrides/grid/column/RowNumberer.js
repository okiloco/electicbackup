Ext.define('Ext.theme.touchsizing.grid.column.RowNumberer', {
    override: 'Ext.grid.column.RowNumberer',
    
    width: 50
});