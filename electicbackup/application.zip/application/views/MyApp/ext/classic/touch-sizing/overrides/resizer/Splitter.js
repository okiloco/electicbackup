Ext.define('Ext.theme.touchsizing.resizer.Splitter', {
    override: 'Ext.resizer.Splitter',
    
    size: 16
});
