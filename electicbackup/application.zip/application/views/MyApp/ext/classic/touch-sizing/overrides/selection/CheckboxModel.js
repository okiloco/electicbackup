Ext.define('Ext.theme.touchsizing.selection.CheckboxModel', {
    override: 'Ext.selection.CheckboxModel',

    headerWidth: 32
});