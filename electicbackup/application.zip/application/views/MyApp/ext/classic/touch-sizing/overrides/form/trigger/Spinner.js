Ext.define('Ext.theme.touchsizing.form.trigger.Spinner', {
    override: 'Ext.form.trigger.Spinner',

    vertical: false
});