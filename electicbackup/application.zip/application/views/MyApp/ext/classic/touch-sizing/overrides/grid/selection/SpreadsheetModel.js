Ext.define('Ext.theme.touchsizing.grid.selection.SpreadsheetModel', {
    override: 'Ext.grid.selection.SpreadsheetModel',
    
    checkboxHeaderWidth: 32
});