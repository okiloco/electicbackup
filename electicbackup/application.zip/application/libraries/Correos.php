<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Correos
{         
       
        public function correos(){

        }        

        public function enviarCorreo($to,$subject,$message=""){                
                $this->CI = & get_instance();
                $this->CI->load->library('email');
                $configGmail = array(
                    'protocol' => 'smtp',
                    'smtp_host' => 'mail.yesidjassirvergara.com',
                    'smtp_port' => 26,
                    'smtp_user' => 'info@yesidjassirvergara.com',
                    'smtp_pass' => 'electic2015',
                    'mailtype' => 'html',
                    'charset' => 'utf-8',
                    'newline' => "\r\n"
                );   
                  
                $this->CI->email->initialize($configGmail);
         
                $this->CI->email->from('info@yesidjassirvergara.com');
                $this->CI->email->to($to);
                $this->CI->email->subject($subject);
                $this->CI->email->message($message);
                $this->CI->email->send();            
        }
}